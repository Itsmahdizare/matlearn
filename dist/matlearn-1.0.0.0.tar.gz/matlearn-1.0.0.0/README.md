Welcome to my Machine Learning Library. With the help of this package, you can create machine learning models and algorithms.
Included preprocessing, training, evaluation.

The module supports linear regression to predict the outcome of continuous values. Also, it has logistic regression to predict the outcome of discrete values (classification) in two ways: 1. probability prediction, exact label prediction. All models are trained by the gradient descent algorithm.

When it comes to preprocessing, matlearn provides a variety of algorithms in order to make it easy to train a model.

And after training your model, you can use several different loss functions to validate the power of your model.

This project is completely written by Mahdi Zare and still developing.